package com.xprod.spring.xprod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XprodApplication {

	public static void main(String[] args) {
		SpringApplication.run(XprodApplication.class, args);
	}

}
