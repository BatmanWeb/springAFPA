package com.xprod.spring.xprod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XprodApplicationTests {

	@Test
	void contextLoads() {
	}

}
