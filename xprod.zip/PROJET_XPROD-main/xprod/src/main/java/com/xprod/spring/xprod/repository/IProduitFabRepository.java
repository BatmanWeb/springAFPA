package com.xprod.spring.xprod.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xprod.spring.xprod.domain.ProduitFab;

public interface IProduitFabRepository extends JpaRepository<ProduitFab, Long>{

}
